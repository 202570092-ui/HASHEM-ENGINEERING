# HASHEM ENGINEERING — Android Wrapper

هذا مشروع Android Studio يحوّل إصدار المكتبة متعدد الكتب إلى تطبيق Android يعتمد على WebView ويحفظ بياناته محليًا عبر IndexedDB.

## بناء APK
1. افتح Android Studio.
2. اختر **Open** وحدد مجلد `android_project` بعد فك ضغطه.
3. انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طلبه البرنامج.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. بعد اكتمال البناء اضغط **locate** للحصول على `app-debug.apk`.
6. انقل APK إلى الهاتف وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر في إعدادات Android.

## خصائص الدمج
- ملفات الويب محفوظة داخل `app/src/main/assets/www`.
- JavaScript وDOM Storage مفعّلان لتشغيل التطبيق وقاعدة IndexedDB المحلية.
- نافذة اختيار الملفات مفعّلة لرفع ملفات PDF من الهاتف.
- اسم الحزمة: `com.hashemengineering.library`.
- الحد الأدنى: Android 6.0 (API 23).

## ملاحظة
هذا مشروع مصدر قابل للبناء، وليس ملف APK مبنيًا. بيئة الإنشاء التي أُعد فيها المشروع لا تتضمن Android SDK/Gradle لإنتاج APK هنا. كما أن بيانات IndexedDB محفوظة داخل مساحة التطبيق على الجهاز؛ احرص على تصدير النسخ الاحتياطية من داخل التطبيق.

## بناء APK من الهاتف فقط عبر GitHub Actions
يوجد ملف workflow داخل `.github/workflows/build-apk.yml`. بعد رفع المشروع كاملًا إلى مستودع GitHub باسم `main`:
1. افتح تبويب **Actions** في المستودع.
2. اختر **Build HASHEM ENGINEERING APK**.
3. اضغط **Run workflow** ثم الزر الأخضر للتأكيد.
4. انتظر انتهاء البناء بنجاح.
5. افتح عملية البناء المكتملة، وانزل إلى **Artifacts**.
6. نزّل `HASHEM-ENGINEERING-APK`، ثم فك ضغطه لتحصل على `app-debug.apk`.

ملاحظة: GitHub Actions يحتاج حساب GitHub، وقد تنطبق حدود الاستخدام المجاني. اجعل المستودع Private إذا كنت لا تريد أن يكون كود التطبيق عامًا.
